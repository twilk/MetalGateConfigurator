const $ = (sel, root=document)=> root.querySelector(sel);
const $$ = (sel, root=document)=> Array.from(root.querySelectorAll(sel));

function createRNG(seed){
  let t = seed >>> 0;
  return function(){
    t += 0x6D2B79F5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

const TILES = [
  { id:1,  label:"Change of weight", icon:"swap",        color:"c-green"  },
  { id:2,  label:"Caminata",                     icon:"walk",        color:"c-amber"  },
  { id:3,  label:"Rebound Bounce", icon:"uturn",   color:"c-blue" },
  { id:4,  label:"Outside",      icon:"split",       color:"c-violet" },
  { id:5,  label:"Cross",                        icon:"cross",       color:"c-pink"   },
  { id:6,  label:"Ocho adelante atrás",          icon:"infinity",    color:"c-lime"   },
  { id:7,  label:"Ocho cortado",                 icon:"scissors",    color:"c-green"  },
  { id:8,  label:"Giro to the left",             icon:"rotate-left", color:"c-amber"  },
  { id:9,  label:"Giro to the right",            icon:"rotate-right",color:"c-blue"   },
  { id:10, label:"Boleo ",      icon:"curve",       color:"c-violet" },
  { id:11, label:"Barridas/Arrastre",            icon:"broom",       color:"c-pink"   },
  { id:12, label:"Gancho",                       icon:"hook",        color:"c-lime"   },
  { id:13, label:"Sacadas",                      icon:"merge",       color:"c-green"  },
  { id:14, label:"Giro with sacadas",            icon:"rotate-merge",color:"c-amber"  },
  { id:15, label:"Change embrace", icon:"handshake",   color:"c-blue"   }
];

const initialState = {
  mode: "walkthrough",
  tiles: Object.fromEntries(TILES.map(t => [t.id, {state:"locked"}])),
  buildIndex: 0,
  seed: Date.now() & 0xffffffff
};
let state = JSON.parse(JSON.stringify(initialState));
let prevState = JSON.parse(JSON.stringify(initialState));
let rng = createRNG(state.seed);

const grid = document.getElementById('grid');

function iconUse(id){ return `<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#icon-${id}"/></svg>`; }

function mountGrid(){
  for(const def of TILES){
    const t = document.createElement('button');
    t.type = 'button';
    t.className = `tile ${def.color}`;
    t.dataset.id = def.id;
    t.dataset.state = "locked";
    t.setAttribute('aria-pressed','false');
    t.setAttribute('aria-label', def.label);

    const ic = document.createElement('div');
    ic.className = 'tile__icon';
    ic.innerHTML = iconUse(def.icon);

    const lb = document.createElement('div');
    lb.className = 'tile__label';
    lb.textContent = def.label;

    t.append(ic, lb);
    grid.appendChild(t);
  }
}

function renderDiff(prev, next){
  for(const id of Object.keys(next.tiles)){
    const a = prev.tiles[id].state;
    const b = next.tiles[id].state;
    if(a !== b){
      const el = grid.querySelector(`[data-id="${id}"]`);
      if(el){
        el.dataset.state = b;
        el.setAttribute('aria-pressed', (b === 'active' || b==='highlighted') ? 'true':'false');
      }
    }
  }
}

function setState(updater){
  prevState = JSON.parse(JSON.stringify(state));
  state = updater(JSON.parse(JSON.stringify(state)));
  renderDiff(prevState, state);
}

// fitGrid() removed - using CSS Grid with 1fr instead

function applyStateMap(mapper){
  setState(s=>{
    for(const id of Object.keys(s.tiles)){
      s.tiles[id].state = mapper(+id);
    }
    return s;
  });
}
function presetUpTo14(){ applyStateMap(id => id<=14 ? 'active':'locked'); }
function presetAll(){ applyStateMap(_ => 'active'); }
function presetOnlyCaminata(){ applyStateMap(id => id===2 ? 'active':'locked'); }

function unlockNext(){
  setState(s=>{
    const buildOrder = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
    if(s.buildIndex < buildOrder.length){
      const nextId = buildOrder[s.buildIndex];
      s.tiles[nextId].state = 'active';
      s.buildIndex++;
    }
    return s;
  });
}

function setExclusiveHighlight(id){
  setState(s=>{
    for(const k of Object.keys(s.tiles)){
      if(+k === id){ s.tiles[k].state = 'highlighted'; }
      else{
        const wasActive = (s.tiles[k].state === 'active' || s.tiles[k].state === 'highlighted');
        s.tiles[k].state = wasActive ? 'muted' : 'locked';
      }
    }
    return s;
  });
}
function clearHighlight(){
  setState(s=>{
    for(const k of Object.keys(s.tiles)){
      if(s.tiles[k].state === 'muted' || s.tiles[k].state === 'highlighted'){
        s.tiles[k].state = 'active';
      }
    }
    return s;
  });
}
function toggleTile(id){
  setState(s=>{
    const st = s.tiles[id].state;
    s.tiles[id].state = (st === 'locked') ? 'active'
                      : (st === 'active') ? 'locked'
                      : (st === 'muted')  ? 'active'
                      : 'active';
    return s;
  });
}

function activeIds(s){ return Object.entries(s.tiles).filter(([,v])=> v.state==='active' || v.state==='highlighted').map(([k])=> +k); }
function removeOne(){
  setState(s=>{
    const act = activeIds(s);
    const pool = act.filter(id => id !== 2);
    if(pool.length === 0) return s;
    const pick = pool[Math.floor(rng() * pool.length)];
    s.tiles[pick].state = 'locked';
    for(const k of Object.keys(s.tiles)){
      if(s.tiles[k].state === 'muted') s.tiles[k].state = 'active';
      if(s.tiles[k].state === 'highlighted' && +k !== 2) s.tiles[k].state = 'active';
    }
    return s;
  });
}
function untilCaminata(interval=300){
  let timer = null;
  const step = ()=>{
    const act = activeIds(state);
    if(act.length<=1 && act[0]===2){ clearInterval(timer); return; }
    removeOne();
  };
  timer = setInterval(step, interval);
}

grid.addEventListener('pointerdown', (e)=>{
  const tile = e.target.closest('.tile'); if(!tile) return;
  const id = +tile.dataset.id;
  const action = (e.altKey || e.metaKey) ? 'highlight' : 'toggle';
  requestAnimationFrame(()=>{
    if(action === 'highlight') setExclusiveHighlight(id);
    else toggleTile(id);
  });
}, {passive:true});

grid.addEventListener('dblclick', (e)=>{
  const tile = e.target.closest('.tile'); if(!tile) return;
  const id = +tile.dataset.id;
  setExclusiveHighlight(id);
});

// Mode buttons
document.getElementById('btnModeWalkthrough').addEventListener('click', ()=> setMode('walkthrough'));
document.getElementById('btnModeMirroring').addEventListener('click', ()=> setMode('mirroring'));
document.getElementById('btnModeCallResponse').addEventListener('click', ()=> setMode('call-response'));
document.getElementById('btnModeBuild').addEventListener('click', ()=> setMode('build'));
document.getElementById('btnModeSubtractive').addEventListener('click', ()=> setMode('subtractive'));

// Preset buttons
document.getElementById('btnAll').addEventListener('click', presetAll);
document.getElementById('btn14').addEventListener('click', presetUpTo14);
document.getElementById('btnOnlyCam').addEventListener('click', presetOnlyCaminata);

// Action buttons
document.getElementById('btnUnlockNext').addEventListener('click', unlockNext);
document.getElementById('btnRemove').addEventListener('click', removeOne);
document.getElementById('btnUntil').addEventListener('click', ()=> untilCaminata(300));
document.getElementById('btnProjector').addEventListener('click', ()=>{
  document.documentElement.classList.toggle('Projector');
});

window.addEventListener('keydown', (e)=>{
  if(e.key==='Escape') return clearHighlight();
  if(e.key===' ') { e.preventDefault(); return removeOne(); }
  if(e.key==='U' || e.key==='u') return unlockNext();
  if(e.key==='A' || e.key==='a') return presetAll();
  if(e.key==='L' || e.key==='l') return presetOnlyCaminata();
  if(e.key==='F' || e.key==='f') return document.body.requestFullscreen?.();
  if(e.key==='H' || e.key==='h') return document.documentElement.classList.toggle('Projector');

  const map = {'1':1,'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'0':10,'q':11,'w':12,'e':13,'r':14,'t':15};
  const k = e.key.toLowerCase();
  if(map[k]) setExclusiveHighlight(map[k]);
});

if(navigator.getBattery){
  navigator.getBattery().then(b=>{
    if(b.level < 0.25) document.documentElement.classList.add('LowPower');
    b.addEventListener('levelchange', ()=>{
      if(b.level < 0.25) document.documentElement.classList.add('LowPower');
      else document.documentElement.classList.remove('LowPower');
    });
  }).catch(()=>{});
}

function setMode(mode){
  setState(s=>{
    s.mode = mode;
    return s;
  });
  updateModeUI();
}

function updateModeUI(){
  const modes = ['walkthrough', 'mirroring', 'call-response', 'build', 'subtractive'];
  modes.forEach(mode => {
    const button = document.getElementById(`btnMode${mode.charAt(0).toUpperCase() + mode.slice(1).replace('-', '')}`);
    if(button){
      button.classList.toggle('active', state.mode === mode);
    }
  });
}

function init(){
  mountGrid();
  presetUpTo14();
  updateModeUI();
}
init();
